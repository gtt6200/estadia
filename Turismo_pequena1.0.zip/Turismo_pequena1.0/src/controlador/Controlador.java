package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Autobus;
import modelo.AutobusDAO;
import vista.Vista;

public class Controlador implements ActionListener{

    AutobusDAO dao = new AutobusDAO();
    Autobus auto = new Autobus();
    Vista vista = new Vista();
    DefaultTableModel modelo = new DefaultTableModel();
    
    public Controlador(Vista v){
        this.vista=v;
        this.vista.btn_mostrar.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==vista.btn_mostrar) {
            mostrar(vista.tabla);
        }
        
    }
    
    public void mostrar(JTable tabla){
    
        modelo = (DefaultTableModel)tabla.getModel();
        List<Autobus>lista=dao.mostrar();
        Object[]objeto =  new Object[5];
        for (int i = 0; i < lista.size(); i++) {
            objeto[0] = lista.get(i).getNumero_unidad();
            objeto[1] = lista.get(i).getModelo();
            objeto[2] = lista.get(i).getMarca();
            objeto[3] = lista.get(i).getEjes();
            objeto[4] = lista.get(i).getKm();
            modelo.addRow(objeto);
        }
        vista.tabla.setModel(modelo);
    }
    
}
