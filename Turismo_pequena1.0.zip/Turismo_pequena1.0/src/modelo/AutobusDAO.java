package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AutobusDAO {
    Conexion conectar = new Conexion();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    
    public List mostrar(){
        List<Autobus>datos=new ArrayList<>();
        String sql = "SELECT * FROM autobuses";
        
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                Autobus auto = new Autobus();
                auto.setNumero_unidad(rs.getInt(0));
                auto.setModelo(rs.getString(1));
                auto.setMarca(rs.getString(2));
                auto.setEjes(rs.getInt(3));
                auto.setKm(rs.getDouble(4));
                datos.add(auto);
            }
        } catch (Exception e) {
        }
        
        return datos;
    }
}
