package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
public class Conexion {

    Connection conn = null;
    public Connection getConnection(){
     String url = "jdbc:mys://127.0.0.1/autobuses";
     String user = "root";
     String pass = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
           // e.printStackTrace();
        }
        return conn;
    }
}
//ClassNotFoundException | SQL