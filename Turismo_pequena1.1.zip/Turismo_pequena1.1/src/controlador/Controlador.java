package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Autobus;
import modelo.AutobusDAO;
import vista.Vista;

public class Controlador implements ActionListener{

    AutobusDAO dao = new AutobusDAO();
    Autobus auto = new Autobus();
    Vista vista = new Vista();
    DefaultTableModel modelo = new DefaultTableModel();
    
    public Controlador(Vista v){
        this.vista = v;
        this.vista.btn_mostrar.addActionListener(this);
        this.vista.btn_guardar.addActionListener(this);
        this.vista.btn_editar.addActionListener(this);
        this.vista.btn_ok.addActionListener(this);
        this.vista.txt_id.setVisible(false);
        this.vista.btn_eliminar.addActionListener(this);
        mostrar(vista.tabla);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btn_mostrar) {
            LimpiarTabla();
            mostrar(vista.tabla);
        }
        if (e.getSource() == vista.btn_guardar) {
            agregar();
            LimpiarTabla();
            mostrar(vista.tabla);
        }
        if (e.getSource() == vista.btn_editar){
            int fila = vista.tabla.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila");
            }else{
                int id = Integer.parseInt((String)vista.tabla.getValueAt(fila,0).toString());
                int unidad =  Integer.parseInt((String)vista.tabla.getValueAt(fila, 1).toString());
                String modeloA = (String)vista.tabla.getValueAt(fila, 2);
                String marca = (String)vista.tabla.getValueAt(fila, 3);
                int eje = Integer.parseInt((String)vista.tabla.getValueAt(fila, 4).toString());
                double km = Double.parseDouble((String)vista.tabla.getValueAt(fila, 5).toString());
                vista.txt_id.setText(""+id);
                vista.txt_numeroUnidad.setText(""+unidad);
                vista.txt_modelo.setText(modeloA);
                vista.txt_marca.setText(marca);
                vista.txt_ejes.setText(""+eje);
                vista.txt_km.setText(""+km);
            }
        }
        if (e.getSource() == vista.btn_ok){
            Actualizar();
            LimpiarTabla();
            mostrar(vista.tabla);
        }
        if (e.getSource() == vista.btn_eliminar) {
            Delete();
            LimpiarTabla();
            mostrar(vista.tabla);
        }
    }
    public void Delete(){
        int dialogo = JOptionPane.YES_NO_OPTION;
        int fila = vista.tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila");
        }else{
            int response = JOptionPane.showConfirmDialog(vista, "¿Desea eliminar el elemento ?", "Eliminar", dialogo, JOptionPane.WARNING_MESSAGE);
            if (response ==  0) {
                int id = Integer.parseInt((String)vista.tabla.getValueAt(fila, 0).toString());
                dao.Eliminar(id);
                JOptionPane.showMessageDialog(vista, "Autobus eliminado correctamente");
            }
            
        }
    }
    void LimpiarTabla(){
        for (int i = 0; i < vista.tabla.getRowCount() ; i++) {
            modelo.removeRow(i);
            i=i-1;
        }
    }
    public void Actualizar(){
        int ide = Integer.parseInt(vista.txt_id.getText());
        int unidad = Integer.parseInt(vista.txt_numeroUnidad.getText());
        String modelo = vista.txt_modelo.getText();
        String marca = vista.txt_marca.getText();
        int eje = Integer.parseInt(vista.txt_ejes.getText());
        double km = Double.parseDouble(vista.txt_km.getText());
        auto.setId(ide);
        auto.setNumero_unidad(unidad);
        auto.setModelo(modelo);
        auto.setMarca(marca);
        auto.setEjes(eje);
        auto.setKm(km);
        int res = dao.Actualizar(auto);
        if (res == 1) {
            JOptionPane.showMessageDialog(vista, "Campos actualizados correctanemte");
        }else{
            JOptionPane.showMessageDialog(vista, "Error al guardar cambios");
        }
    }
    public void agregar(){
        int unidad = Integer.parseInt(vista.txt_numeroUnidad.getText());
        String modelo = vista.txt_modelo.getText();
        String marca = vista.txt_marca.getText();
        int eje = Integer.parseInt(vista.txt_ejes.getText());
        double km = Double.parseDouble(vista.txt_km.getText());
        auto.setNumero_unidad(unidad);
        auto.setModelo(modelo);
        auto.setMarca(marca);
        auto.setEjes(eje);
        auto.setKm(km);
        int res = dao.Agregar(auto);
        if (res == 1) {
            JOptionPane.showMessageDialog(vista, "Autobus Agregado Exitosamente");
        }else{
            JOptionPane.showMessageDialog(vista, "Error al agregar el autobus");
        }
    }
    public void mostrar(JTable tabla){
        modelo = (DefaultTableModel)tabla.getModel();
        List<Autobus>lista=dao.mostrar();
        Object[]objeto =  new Object[6];
        for (int i = 0; i < lista.size(); i++) {
            objeto[0] = lista.get(i).getId();
            objeto[1] = lista.get(i).getNumero_unidad();
            objeto[2] = lista.get(i).getModelo();
            objeto[3] = lista.get(i).getMarca();
            objeto[4] = lista.get(i).getEjes();
            objeto[5] = lista.get(i).getKm();
            modelo.addRow(objeto);
        }
        vista.tabla.setModel(modelo);
    }

}
