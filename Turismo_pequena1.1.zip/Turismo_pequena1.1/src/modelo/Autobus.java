package modelo;

import java.util.Objects;

public class Autobus {
    int id;
    int numero_unidad;
    String modelo;
    String marca;
    int ejes;
    double km;
    
    public Autobus(){
    
    }
    public Autobus(int id, int numero_unidad, String modelo, String marca, int ejes, double km) {
        this.id = id;
        this.numero_unidad = numero_unidad;
        this.modelo = modelo;
        this.marca = marca;
        this.ejes = ejes;
        this.km = km;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getNumero_unidad() {
        return numero_unidad;
    }

    public void setNumero_unidad(int numero_unidad) {
        this.numero_unidad = numero_unidad;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getEjes() {
        return ejes;
    }

    public void setEjes(int ejes) {
        this.ejes = ejes;
    }

    public double getKm() {
        return km;
    }

    public void setKm(double km) {
        this.km = km;
    }
    
}
