package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
//import javax.swing.JOptionPane;

public class AutobusDAO {
    Conexion conectar = new Conexion();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    
    public List mostrar(){
        List<Autobus>datos=new ArrayList<>();
        String sql = "SELECT * FROM autobuses.autobuses";
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                Autobus auto = new Autobus();
                auto.setId(rs.getInt(1));
                auto.setNumero_unidad(rs.getInt(2));
                System.out.println(auto.getNumero_unidad());
                auto.setModelo(rs.getString(3));
                auto.setMarca(rs.getString(4));
                auto.setEjes(rs.getInt(5));
                auto.setKm(rs.getDouble(6));
                datos.add(auto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datos;
    }
    public int Agregar(Autobus auto){
        String sql = "INSERT INTO autobuses.autobuses(Numero_unidad, Modelo, Marca, Numero_ejes, Kilometros_recorridos) VALUES(?,?,?,?,?)";
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1,auto.numero_unidad);
            ps.setString(2, auto.modelo);
            ps.setString(3, auto.marca);
            ps.setInt(4, auto.ejes);
            ps.setDouble(5, auto.km);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return 1;
    }

    public int Actualizar(Autobus auto){
        int ret = 0;
        String sql = "UPDATE autobuses.autobuses SET Numero_unidad=?, Modelo=?, Marca=?, Numero_ejes=?, Kilometros_recorridos=? WHERE Id=? ";
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(6, auto.getId());
            ps.setInt(1,auto.getNumero_unidad());
            ps.setString(2, auto.getModelo());
            ps.setString(3, auto.getMarca());
            ps.setInt(4, auto.getEjes());
            ps.setDouble(5, auto.getKm());
            ret = ps.executeUpdate();
            if (ret == 1) {
                System.out.println("Se ejecuto la consulta");
                return 1;
            } else {
                System.out.println("No se ejecuto la consulta");
                return 0;
            }
        } catch (Exception e) {
        }        
        return 1;
    }
    public void Eliminar(int id){
        String sql = "DELETE FROM autobuses.autobuses WHERE Id=" + id;
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
}
