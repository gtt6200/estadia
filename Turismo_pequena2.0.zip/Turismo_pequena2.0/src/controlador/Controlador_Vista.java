
package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.Vista_Principal;
import vista.VistaBitacora;
public class Controlador_Vista implements ActionListener{
    Vista_Principal vista = new Vista_Principal();
    VistaBitacora vistaB = new VistaBitacora();
    public Controlador_Vista(Vista_Principal v){
    this.vista = v;
    this.vista.btnVista_bitacora.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnVista_bitacora){
        MostarBitacora();
        }
    }
    public void MostarBitacora(){
        vistaB.setLocationRelativeTo(null);
        vistaB.setVisible(true);
        vista.hide();
    }
}
