package modelo;

import java.sql.Date;

public class Bitacora {
    int economico;
    String chasis;
    int num_obra;
    java.sql.Date fecha;
    double km_servicio;
    String tipo_mtto;
    double km_proximo_servicio;
    String prox_mtto;
    String motor;
    double ultimo_km;
    java.sql.Date fecha_ultimo_km;
    double km_restantes;
    public Bitacora(){
    
    }
    

    public Bitacora(int economico, String chasis, int num_obra, Date fecha, double km_servicio, String tipo_mtto,
            double km_proximo_servicio, String prox_mtto, String motor, double ultimo_km, Date fecha_ultimo_km,
            double km_restantes) {
        this.economico = economico;
        this.chasis = chasis;
        this.num_obra = num_obra;
        this.fecha = fecha;
        this.km_servicio = km_servicio;
        this.tipo_mtto = tipo_mtto;
        this.km_proximo_servicio = km_proximo_servicio;
        this.prox_mtto = prox_mtto;
        this.motor = motor;
        this.ultimo_km = ultimo_km;
        this.fecha_ultimo_km = fecha_ultimo_km;
        this.km_restantes = km_restantes;
    }

    public int getEconomico() {
        return economico;
    }

    public void setEconomico(int economico) {
        this.economico = economico;
    }

    public String getChasis() {
        return chasis;
    }

    public void setChasis(String chasis) {
        this.chasis = chasis;
    }

    public int getNum_obra() {
        return num_obra;
    }

    public void setNum_obra(int num_obra) {
        this.num_obra = num_obra;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getKm_servicio() {
        return km_servicio;
    }

    public void setKm_servicio(double km_servicio) {
        this.km_servicio = km_servicio;
    }

    public String getTipo_mtto() {
        return tipo_mtto;
    }

    public void setTipo_mtto(String tipo_mtto) {
        this.tipo_mtto = tipo_mtto;
    }

    public double getKm_proximo_servicio() {
        return km_proximo_servicio;
    }

    public void setKm_proximo_servicio(double km_proximo_servicio) {
        this.km_proximo_servicio = km_proximo_servicio;
    }

    public String getProx_mtto() {
        return prox_mtto;
    }

    public void setProx_mtto(String prox_mtto) {
        this.prox_mtto = prox_mtto;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public double getUltimo_km() {
        return ultimo_km;
    }

    public void setUltimo_km(double ultimo_km) {
        this.ultimo_km = ultimo_km;
    }

    public Date getFecha_ultimo_km() {
        return fecha_ultimo_km;
    }

    public void setFecha_ultimo_km(Date fecha_ultimo_km) {
        this.fecha_ultimo_km = fecha_ultimo_km;
    }

    public double getKm_restantes() {
        return km_restantes;
    }

    public void setKm_restantes(double km_restantes) {
        this.km_restantes = km_restantes;
    }
    
}
