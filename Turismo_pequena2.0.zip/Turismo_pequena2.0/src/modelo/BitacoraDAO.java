package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
//import java.sql.Date;
public class BitacoraDAO {
    Conexion conectar = new Conexion();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    public List mostrar(){
        List<Bitacora>datos=new ArrayList();
        String sql = "SELECT * FROM turismo.bitacora";
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {                
                Bitacora bit = new Bitacora();
                bit.setEconomico(rs.getInt(1));
                bit.setChasis(rs.getString(2));
                bit.setNum_obra(rs.getInt(3));
                bit.setFecha(rs.getDate(4));
                bit.setKm_servicio(rs.getDouble(5));
                bit.setTipo_mtto(rs.getString(6));
                bit.setKm_proximo_servicio(rs.getDouble(7));
                bit.setProx_mtto(rs.getString(8));
                bit.setMotor(rs.getString(9));
                bit.setUltimo_km(rs.getDouble(10));
                bit.setFecha_ultimo_km(rs.getDate(11));
                bit.setKm_restantes(rs.getDouble(12));
            }
        } catch (Exception e) {
        }
        return datos;
    }
    public int Agregar(Bitacora bit){
        String sql = "INSERT INTO turismo.bitacora (ECONOMICO, CHASIS, NUM_OBRA, FECHA, KMS_SERVICIO, TIPO_MTTO, KMS_PROXIMO_SERVICIO, PROX_MTTO, TIPO_MOTOR, ULTIMO_KMS, FECHA_ULTIMO_KM, KM_RESTANTES) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,)";
        try {
            conn = conectar.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1,bit.economico);
            ps.setString(2, bit.chasis);
            ps.setInt(3, bit.num_obra);
            ps.setDate(4, bit.fecha);
            ps.setDouble(5, bit.km_servicio);
            ps.setString(6, bit.tipo_mtto);
            ps.setDouble(7, bit.km_proximo_servicio);
            ps.setString(8, bit.prox_mtto);
            ps.setString(9, bit.motor);
            ps.setDouble(10, bit.ultimo_km);
            ps.setDate(11, bit.fecha_ultimo_km);
            ps.setDouble(12, bit.km_restantes);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return 1;
    }
}
