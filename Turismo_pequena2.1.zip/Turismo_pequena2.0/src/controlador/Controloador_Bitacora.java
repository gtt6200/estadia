
package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.BitacoraDAO;
import modelo.Bitacora;
import modelo.Conexion;
import vista.VistaBitacora;
public class Controloador_Bitacora implements ActionListener{
        Conexion con = new Conexion();
        BitacoraDAO dao = new BitacoraDAO();
        Bitacora bit = new Bitacora();
        VistaBitacora vista = new VistaBitacora();
        DefaultTableModel modelo = new DefaultTableModel();
     
    public Controloador_Bitacora(VistaBitacora v){
        this.vista = v;
        this.vista.btn_aceptar.addActionListener(this);
        this.vista.btn_editar.addActionListener(this);
        this.vista.btn_guardar.addActionListener(this);
        this.vista.btn_eliminar.addActionListener(this);
        mostrar(vista.table);
    }    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btn_guardar) {
            agregar();
            mostrar(vista.table);
        }
    }
    public void mostrar(JTable tabla){
        modelo = (DefaultTableModel)tabla.getModel();
        List<Bitacora>lista=dao.mostrar();
        Object[]objeto =  new Object[12];
        for (int i = 0; i < lista.size(); i++) {
            objeto[0] = lista.get(i).getEconomico();
            objeto[1] = lista.get(i).getChasis();
            objeto[2] = lista.get(i).getNum_obra();
            objeto[3] = lista.get(i).getFecha();
            objeto[4] = lista.get(i).getKm_servicio();
            objeto[5] = lista.get(i).getTipo_mtto();
            objeto[6] = lista.get(i).getKm_proximo_servicio();
            objeto[7] = lista.get(i).getProx_mtto();
            objeto[8] = lista.get(i).getMotor();
            objeto[9] = lista.get(i).getUltimo_km();
            objeto[10] = lista.get(i).getFecha_ultimo_km();
            objeto[11] = lista.get(i).getKm_restantes();
            modelo.addRow(objeto);
        }
        vista.table.setModel(modelo);
    }
    public void agregar(){
        int ecnomico = Integer.parseInt(vista.txt_economico.getText());
        String chasis = vista.txt_chasis.getText();
        //int num_obra = Integer.parseInt(vista.txt_obra.getText());
       
        java.util.Date fecha = vista.date_fecha.getDate();
        double km_servicio = Double.parseDouble(vista.txt_kmservicio.getText());
        String tipo_mtto = vista.txt_tipomtto.getText();
        double km_prox = Double.parseDouble(vista.txt_kmproximoservicio.getText());
        String prox_mtto = vista.txt_proximomtto.getText();
        String motor = vista.txt_motor.getText();
        double u_km = Double.parseDouble(vista.txt_ultimokm.getText());
        java.util.Date fecha_km = vista.date_km.getDate();
        double km_restantes = Double.parseDouble(vista.txt_ultimokm.getText());
        bit.setEconomico(ecnomico);
        bit.setChasis(chasis);
        boolean num_obra = ValidacionInt(vista.txt_obra.getText());
        if (num_obra != false) {
            bit.setNum_obra(ValidacionInt(num_obra));
        }else{
            JOptionPane.showMessageDialog(vista, "Solo puede ingresar numeros");
        }
        bit.setFecha(Conexion.aSqlDate(fecha));
        bit.setKm_servicio(km_servicio);
        bit.setTipo_mtto(tipo_mtto);
        bit.setKm_proximo_servicio(km_prox);
        bit.setProx_mtto(prox_mtto);
        bit.setMotor(motor);
        bit.setUltimo_km(u_km);
        bit.setFecha_ultimo_km(Conexion.aSqlDate(fecha_km));
        bit.setKm_restantes(km_restantes);
        int res = dao.Agregar(bit);
        if (res == 1) {
            JOptionPane.showMessageDialog(vista, "Registro agregado Exitosamente");
        } else {
            JOptionPane.showMessageDialog(vista, "Error al guardar el registro");
        }
    }
     public boolean ValidacionDouble(String cadena){
        double num;
        try {
            num = Double.parseDouble(cadena);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
     public boolean ValidacionInt(String cadenaentero){
         int numero;
         try {
             numero = Integer.parseInt(cadenaentero);
             return true;
         } catch (Exception e) {
             return false;
         }
     }

    
}
