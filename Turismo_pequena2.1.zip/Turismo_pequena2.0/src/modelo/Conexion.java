/**
 * @author Yuniel
 */
package modelo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
public class Conexion {
    Connection conn = null;
    public Connection getConnection(){
    String url = "jdbc:mysql://localhost/turismo?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
     String user = "root";
     String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException e) {
           e.printStackTrace();
        }
        return conn;
    }
    public static java.sql.Date getFechaActual() {
        //Obtener fecha actual y guardar en String 
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendario = Calendar.getInstance();
        java.util.Date fechaT = (java.util.Date) calendario.getTime();
        String fecha = dateFormat.format(fechaT);
        try {
            fechaT = (Date) dateFormat.parse(fecha);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        java.sql.Date fechaFinal = new java.sql.Date(fechaT.getTime());
        return fechaFinal;
    }

    public static java.sql.Date aSqlDate(java.util.Date miFecha) {
        return new java.sql.Date(miFecha.getTime());
    }

    public static java.util.Date stringADate(String fecha) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.parse(fecha);
    }
}
