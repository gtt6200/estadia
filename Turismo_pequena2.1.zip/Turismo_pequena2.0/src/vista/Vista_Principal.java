
package vista;
import vista.VistaBitacora;
import controlador.Controlador_Vista;
public class Vista_Principal extends javax.swing.JFrame {

    public Vista_Principal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVista_bitacora = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnVista_bitacora.setText("Bitacora");
        btnVista_bitacora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVista_bitacoraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(btnVista_bitacora)
                .addContainerGap(501, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(btnVista_bitacora)
                .addContainerGap(234, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVista_bitacoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVista_bitacoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnVista_bitacoraActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        Vista_Principal v = new Vista_Principal();
        Controlador_Vista c = new Controlador_Vista(v);
        v.setVisible(true);
        v.setLocationRelativeTo(null);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnVista_bitacora;
    // End of variables declaration//GEN-END:variables
}
